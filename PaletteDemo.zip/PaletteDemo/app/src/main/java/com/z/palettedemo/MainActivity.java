package com.z.palettedemo;

import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.graphics.Palette;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        getColor();
    }


    class RecyclerViewAdapter extends RecyclerView.Adapter<ViewHolder> {
        List<Palette.Swatch> swatchList;

        public RecyclerViewAdapter(List<Palette.Swatch> swatchList) {
            this.swatchList = swatchList;
        }


        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_main, viewGroup, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

            viewHolder.mView.setBackgroundColor(swatchList.get(i).getRgb());
        }

        @Override
        public int getItemCount() {
            return swatchList.size();
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView mView;

        public ViewHolder(View itemView) {
            super(itemView);
            mView = itemView.findViewById(R.id.image);
        }
    }

    private void getColor() {

        //目标bitmap
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.aa);

        Palette.Builder builder = Palette.from(bitmap);
        builder.maximumColorCount(8);
        builder.addFilter(new Palette.Filter() {
            @Override
            public boolean isAllowed(int i, @NonNull float[] floats) {

                StringBuilder builder1=new StringBuilder();
                for(Float f:floats){
                    builder1.append(f+"-");
                }
                Log.d("test",i+"____"+ builder1.toString());
                return true;
            }
        });
        builder.generate(new Palette.PaletteAsyncListener() {
            @Override
            public void onGenerated(Palette palette) {

                List<Palette.Swatch> swatchList = palette.getSwatches();


                recyclerView.setAdapter(new RecyclerViewAdapter(swatchList));

                Palette.Swatch vibrantSwatch = palette.getVibrantSwatch();//获取有活力的颜色样本
                //   view1.setBackgroundColor(vibrantSwatch.getTitleTextColor());
 /*               Palette.Swatch lightVibrantSwatch = palette.getLightVibrantSwatch();//获取有活力 亮色的样本
                view2.setBackgroundColor(lightVibrantSwatch.getRgb());

                Palette.Swatch drakVibrantSwatch = palette.getDarkVibrantSwatch();//获取有活力 暗色的样本
                view3.setBackgroundColor(drakVibrantSwatch.getRgb());
                Palette.Swatch mutedSwatch = palette.getMutedSwatch();//获取柔和的颜色样本
                view4.setBackgroundColor(mutedSwatch.getRgb());
                Palette.Swatch lightMutedSwatch = palette.getLightMutedSwatch();//获取柔和 亮色的样本
                view5.setBackgroundColor(lightMutedSwatch.getRgb());*/
                Palette.Swatch darkMutedSwatch = palette.getDarkMutedSwatch();//获取柔和 暗色的样本
                //  view1.setBackgroundColor(darkMutedSwatch.getRgb());
            }
        });


    }
}
